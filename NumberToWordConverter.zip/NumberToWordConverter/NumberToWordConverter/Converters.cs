﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using NumberConverterToText;

namespace GUI.Converters
{	
	public class DoubleConverter : IValueConverter
	{
		// Converts double to int
		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			double v = (double)value;
			return (int)v;
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			return value;
		}
	}
	public class NumberToWordConverter : IValueConverter
	{
		// Converts int to textual representation
		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
            if (String.IsNullOrEmpty((string)value))
            {
                return null;
            }
            else
            {
                int v = int.Parse((string)value);
                return Converter.ConvertNumberToString(v);
            }
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			return value;
		}
	}
}
