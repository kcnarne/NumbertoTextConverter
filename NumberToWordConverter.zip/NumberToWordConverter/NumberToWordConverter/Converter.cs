﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberConverterToText
{
	public static class Converter
	{
		//converts any number between 0 & INT_MAX (2,147,483,647)
		public static string ConvertNumberToString(int n)
		{
			if (n < 0)
				throw new NotSupportedException("Negative Numbers Not Supported");
			if (n == 0)
				return "Zero";
			if (n < 10)
				return ConvertDigitToString(n);
			if (n < 20)
				return ConvertTeensToString(n);
			if (n < 100)
				return ConvertHighTensToString(n);
			if (n < 1000)
				return ConvertBigNumberToString(n, (int)1e2, "Hundred");
			if (n < 1e6)
				return ConvertBigNumberToString(n, (int)1e3, "Thousand");
			if (n < 1e9)
				return ConvertBigNumberToString(n, (int)1e6, "Million");
			//if (n < 1e12)
			return ConvertBigNumberToString(n, (int)1e9, "Billion");
		}

		private static string ConvertDigitToString(int i)
		{
			switch (i)
			{
				case 0: return "";
				case 1: return "One";
				case 2: return "Two";
				case 3: return "Three";
				case 4: return "Four";
				case 5: return "Five";
				case 6: return "Six";
				case 7: return "Seven";
				case 8: return "Eight";
				case 9: return "Nine";
				default:
					throw new IndexOutOfRangeException(String.Format("{0} not a digit",i));
			}
		}

		//assumes a number between 10 & 19
		private static string ConvertTeensToString(int n)
		{
			switch (n)
			{
				case 10: return "Ten";
				case 11: return "Eleven";
				case 12: return "Twelve";
				case 13: return "Thirteen";
				case 14: return "Fourteen";
				case 15: return "Fiveteen";
				case 16: return "Sixteen";
				case 17: return "Seventeen";
				case 18: return "Eighteen";
				case 19: return "Nineteen";
				default:
					throw new IndexOutOfRangeException(String.Format("{0} not a teen", n));
			}
		}

		//assumes a number between 20 and 99
		private static string ConvertHighTensToString(int n)
		{
			int tensDigit = (int)( Math.Floor((double)n / 10.0));

			string tensStr;
			switch (tensDigit)
			{
				case 2: tensStr = "Twenty"; break;
				case 3: tensStr = "Thirty"; break;
				case 4: tensStr = "Forty"; break;
				case 5: tensStr = "Fifty"; break;
				case 6: tensStr = "Sixty"; break;
				case 7: tensStr = "Seventy"; break;
				case 8: tensStr = "Eighty"; break;
				case 9: tensStr = "Ninety"; break;
				default:
					throw new IndexOutOfRangeException(String.Format("{0} not in range 20-99", n));
			}
			if (n % 10 == 0) return tensStr;
			string onesStr = ConvertDigitToString(n - tensDigit * 10);
			return tensStr + " " + onesStr;
		}
		
		// Use this to convert any integer bigger than 99
		private static string ConvertBigNumberToString(int n, int baseNum, string baseNumStr)
		{
			// special case: use commas to separate portions of the number, unless we are in the hundreds
			string separator = (baseNumStr != "Hundred") ? ", " : " ";

			// Strategy: translate the first portion of the number, then recursively translate the remaining sections.
			// Step 1: strip off first portion, and convert it to string:
			int bigPart = (int)(Math.Floor((double)n / baseNum));
			string bigPartStr = ConvertNumberToString(bigPart) + " " + baseNumStr;
			// Step 2: check to see whether we're done:
			if (n % baseNum == 0) return bigPartStr;
			// Step 3: concatenate 1st part of string with recursively generated remainder:
			int restOfNumber = n - bigPart * baseNum;
			return bigPartStr + separator + ConvertNumberToString(restOfNumber);
		}
	}
}








